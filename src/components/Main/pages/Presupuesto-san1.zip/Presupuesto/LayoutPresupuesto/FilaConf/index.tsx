import React from "react";

import FilaConf from "./FilaConf";
// import FilaAnexo from "./FilaAnexo/FilaAnexo"
export default function FilaUno() {

  return (
    <>
      <FilaConf />
      {/* <FilaAnexo /> */}
    </>
  );
}
