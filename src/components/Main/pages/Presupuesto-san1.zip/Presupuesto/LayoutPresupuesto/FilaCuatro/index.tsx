import React from "react";

import FilaCuatro from "./FilaCuatro";

export default function Fila() {

  return (
    <>
      <FilaCuatro />
    </>
  );
}
