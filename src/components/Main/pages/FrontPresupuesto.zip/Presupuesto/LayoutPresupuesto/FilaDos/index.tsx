import React from "react";

import FilaDos from "./FilaDos";
export default function Fila() {
  return (
    <>
      <FilaDos />
    </>
  );
}
