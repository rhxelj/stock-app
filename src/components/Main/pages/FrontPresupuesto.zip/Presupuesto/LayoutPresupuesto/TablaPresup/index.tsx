import React from "react";

import TablaPresup from "./TablaPresup";

export default function Fila() {
  return (
    <>
      <TablaPresup />
    </>
  );
}
