export const initialState = {
  idStkItems: 0,
  StkItemsGrupo: 0,
  StkItemsRubro: 0,
  StkItemsDesc: "",
  StkItemsCantidad: 0,
  StktemsFAct: "",
  StkItemsMin: 0,
  StkItemsMax: 0,
  items: [],
  itemsdetalles: [],
  stkgrupoitem: [],
};
