export const initial_state = {
  //Funcions agregaStock BEGIN ***//
  idStkGrupo: "",
  idStkRubro: "",
  idStkItems: "",
  cantidad: 1.0,
  StkRubroPres: null,

  // stkitemsmodstock

  // idStkGrupo
  // idStkRubro
  // idStkItems
  // cantidad
  // StkRubroPres
  StkItemsCantDisp: 0.0,
  StkItemsCantidad: 0.0,

  // stkenvaseagregar

  // idStkGrupo
  // idStkRubro
  // idStkItems
  // cantidad
  // StkRubroPres
  StkEnvasePartida: "",
  StkEnvaseUbG: "",
  StkEnvaseUbF: "",
  StkEnvaseObserv: "",

  disponibilidad: 0,
  //Funcions agregaStock END ***//

  stkgrupo: [],
  stkrubro: [],
  stkitems: [],

  //F2C2
  stkitemsele: [],
  StkItemsFAct: "",
  StkItemsMin: "",
  StkItemsMax: "",
  // StkItemsCantDisp: 0,
  // StkItemsCantidad: 0,

  //FilaTres
  // stkitemsele: [],
  // StkItemsFAct: "",
  // StkRubroPres: "",
  StkRubroPresDes: "",
  StkRubroUM: "",
  StkRubroAncho: 0,
  // cantidad: "",
  largo: "",
  ancho: "",
  indice: "",
  faltante: 0, //valor de prueba solo para ver si cambia
  total: 0, //valor de prueba solo para ver si cambia
  // StkItemsMin: "",
  // StkItemsMax: "",
  // StkItemsCantDisp: 0,

  //FilaCuatro1
  // StkEnvasePartida: "",
  // StkEnvaseUbG: "",
  // StkEnvaseUbF: "",
  // StkEnvaseObserv: "",
  stkenvaseubfisica: [],

  imp_etiquetas: false,

  confOpen: false, // Estado del componnente confirmacion
  noImp: false,
  impOk: false,
  exito: false,
  // StkItemsFAct: "",
  // StkItemsMin: null,
  // StkItemsMax: null,
  // StkRubroAncho: null,
  // StkRubroPresDes: null,
  // faltante: 0.0,
  // total: 0.0,
  // datostraid: [],
  // open: true,
  // toggle_imprimir: false,
  // marcagenqr: false,
  // imp_conf: false,
  // marcaagregado: false,
  // toggle_state: {
  //   entrada: true,
  //   dialogo: false, //TODO antiguamente dialogo borrar una vez que funcione
  //   imprimir: false
  // stkenvaseubg: [],
  // ubicacionf: [],
  // stkrubroele: [],

  // dialogo_imprimir: false,
  // StkItemsGrupo: 0,

  // stkrubro: [],
  // stkgrupo: [],
  // stkitems: [],
  // StkItemsCantidad: 0.0,
  // StkItemsCantDisp: 0.0,
  // StkItemsFAct: "",
  // StkItemsMin: 0.0,
  // StkItemsMax: 0.0,
  TConfec: 0,
  // cantidad: 1.0,
  // largo: 0.0,
  // ancho: 0.0,
  // faltante: 0.0,
  // total: 0.0,
  datostraid: [],
  open: true,
  marcaver: false,
  // }
};
