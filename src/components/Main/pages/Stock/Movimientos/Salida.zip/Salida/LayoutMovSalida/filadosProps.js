export const filados = {
  idStkGrupo: state.idStkGrupo,
  handleChange: handleChange,
  stkgrupo: state.stkgrupo
};
