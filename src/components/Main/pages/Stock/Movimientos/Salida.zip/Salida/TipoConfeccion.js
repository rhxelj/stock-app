export const TipoConfeccion = [
  {
    indice: 1,
    detalle: "Con Dobladillo",
  },
  {
    indice: 2,
    detalle: "Con Fajas",
  },
  {
    indice: 3,
    detalle: "Paño Unido",
  },
  {
    indice: 4,
    detalle: "Enrollable",
  },
];
