import React from "react";

import FilaCinco from "./FilaCinco";

export default function Fila() {
  return (
    <>
      <FilaCinco />
    </>
  );
}
