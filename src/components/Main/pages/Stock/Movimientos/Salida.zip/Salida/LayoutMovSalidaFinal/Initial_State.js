export const initial_state = {
  codqr: "",
  cantidad: "",
  largo: "",
  cantarestar: 0,
  detalle: "",
  nroenvase: "",
  grupo: "",
  item: "",
  rubro: "",
  StkItemsDesc: "",
  StkItemsFAct: "",
  StkItemsMin: null,
  StkItemsMax: null,
  StkItemsCantDisp: 0,
  StkItemsCantidad: 0,
  // Esto es para la funionalidad de Impresion de eitiquetas
  imp_etiquetas: false,
  confOpen: false, // Estado del componnente confirmacion
  noImp: false,
  impOk: false,
};
