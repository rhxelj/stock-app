import React from "react";
import {
  Box,
  Button,
  Container,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  IconButton,
  InputAdornment,
  Paper,
  TextField,
  Typography
} from "@material-ui/core";
// import { makeStyles } from "@material-ui/core/styles";
// import Paper from "@material-ui/core/Paper";
// import Grid from "@material-ui/core/Grid";
// import useStyles from "./styles";
import FilaUno from "./FilaUno1";

export default function Fila() {
  // const classes = useStyles();

  return (
    <>
      <FilaUno />
    </>
  );
}
